# ChurnIQ — Customer Churn Prediction and Analytics Dashboard

ChurnIQ is a student Data Analytics and Visualization project that demonstrates a customer-churn analytics dashboard and a Python machine-learning backend. The repository includes the web interface, a reproducible synthetic dataset, model-training code, a FastAPI prediction service, saved demonstration model artifacts, tests, and project documentation.

> **Dataset and results disclosure:** The included 5,000-row dataset is synthetically generated for coursework and software testing. It does not represent real customers or a real telecom company. Metrics from this dataset are demonstration results only and must not be presented as real-world predictive performance.

## Contents

```text
ChurnIQ_Customer_Churn_Prediction/
├── README.md
├── .gitignore
├── requirements.txt
├── src/
│   ├── churniq_customer_churn_prediction.html
│   ├── css/
│   │   └── styles.css
│   └── js/
│       ├── app.js
│       ├── data.js
│       ├── utils.js
│       ├── customer-dashboard.js
│       ├── prediction.js
│       └── copilot.js
├── backend/
│   ├── README.md
│   ├── __init__.py
│   ├── churniq/
│   │   ├── __init__.py
│   │   ├── preprocessing.py
│   │   ├── train_model.py
│   │   └── api.py
│   └── tests/
│       └── test_preprocessing.py
├── data/
│   ├── README.md
│   ├── customer_churn.csv
│   ├── customer_churn_sample_100.csv
│   ├── DATA_DICTIONARY.csv
│   ├── generate_synthetic_data.py
│   └── TRAINING_STATUS.txt
├── models/
│   ├── README.md
│   ├── churn_model.joblib
│   └── model_metadata.json
└── docs/
    ├── ABSTRACT.md
    ├── BACKEND_ML_GUIDE.md
    ├── ChurnIQ_Project_Abstract.docx
    ├── ChurnIQ_Project_Report.docx
    ├── PROJECT_REPORT.md
    ├── SOURCE_CODE_GUIDE.md
    ├── TEST_CASES.md
    └── VIVA_CODE_EXPLANATION.md
```

## Features

### Web interface
- Dashboard and customer summary views
- Customer directory with search and risk filters
- Customer detail view
- Churn-risk demonstration form
- Analytics and model-comparison screens
- Local Copilot-style demonstration
- CSV export
- Responsive HTML/CSS/JavaScript interface

### Python machine-learning backend
- Dataset loading and target cleanup
- Numeric and categorical missing-value imputation
- Numeric feature scaling
- Categorical one-hot encoding
- Logistic Regression and Random Forest training
- Stratified train/test split
- Accuracy, precision, recall, F1-score and ROC-AUC evaluation
- Model selection and serialization with Joblib
- FastAPI endpoints for health, model metadata and prediction

## Technology stack

- **Frontend:** HTML5, CSS3, JavaScript ES modules
- **Data processing:** Python, Pandas, NumPy
- **Machine learning:** scikit-learn
- **Model persistence:** Joblib
- **API:** FastAPI, Uvicorn
- **Testing:** Pytest

## Requirements

- Python 3.10 or newer recommended
- A modern browser
- Visual Studio Code (recommended, optional)

## Quick start

Run commands from the repository root directory.

### 1. Create a virtual environment

macOS / Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

Windows PowerShell:

```powershell
python -m venv .venv
.venv\\Scripts\\Activate.ps1
```

### 2. Install Python dependencies

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 3. Train the machine-learning models

The synthetic dataset is already included. Run:

```bash
python -m backend.churniq.train_model --data data/customer_churn.csv
```

The training script compares Logistic Regression and Random Forest using a stratified 80/20 split. It selects the model using ROC-AUC, with F1-score as the tie-breaker, and saves:

- `models/churn_model.joblib`
- `models/model_metadata.json`

The repository already includes demonstration artifacts generated from the synthetic dataset. Run training again whenever you change the dataset or training code.

### 4. Start the prediction API

```bash
uvicorn backend.churniq.api:app --reload
```

API addresses:

- Health: http://127.0.0.1:8000/health
- Model information: http://127.0.0.1:8000/model-info
- Interactive API documentation: http://127.0.0.1:8000/docs

### 5. Run the frontend

Open a second terminal from the repository root:

```bash
python -m http.server 5500 --directory src
```

Open this address in your browser:

http://127.0.0.1:5500/churniq_customer_churn_prediction.html

The frontend is currently a standalone interactive prototype. Its prediction form still uses a JavaScript demonstration rule; it is **not yet connected** to the Python `/predict` endpoint. The FastAPI backend can be tested separately using `/docs`.

## Prediction API example

The API expects the same feature names and compatible values used when training the model. For the included Telco-style synthetic dataset, an example request is:

```bash
curl -X POST "http://127.0.0.1:8000/predict" \
  -H "Content-Type: application/json" \
  -d '{
    "customer": {
      "gender": "Female",
      "SeniorCitizen": 0,
      "Partner": "Yes",
      "Dependents": "No",
      "tenure": 12,
      "PhoneService": "Yes",
      "MultipleLines": "No",
      "InternetService": "Fiber optic",
      "OnlineSecurity": "No",
      "OnlineBackup": "Yes",
      "DeviceProtection": "No",
      "TechSupport": "No",
      "StreamingTV": "Yes",
      "StreamingMovies": "No",
      "Contract": "Month-to-month",
      "PaperlessBilling": "Yes",
      "PaymentMethod": "Electronic check",
      "MonthlyCharges": 75.5,
      "TotalCharges": 905.0
    }
  }'
```

The API returns the churn probability, predicted class, risk category and selected model. Use real, valid feature values for any experiment; the example is only a request-format illustration.

## Dataset

The generated dataset contains 5,000 synthetic customer records, a 100-row sample, a data dictionary and a reproducible generator script.

To regenerate it:

```bash
python data/generate_synthetic_data.py
```

The generator uses a fixed random seed, so it produces reproducible data. Read [`data/README.md`](data/README.md) for the schema and limitations.

## Demonstration model results

The included model metadata records the held-out test-split results from the synthetic dataset:

| Metric | Logistic Regression | Random Forest |
|---|---:|---:|
| Accuracy | 66.70% | 67.50% |
| Precision | 48.09% | 48.26% |
| Recall | 71.75% | 44.13% |
| F1-score | 57.58% | 46.10% |
| ROC-AUC | 73.36% | 70.61% |

Logistic Regression was selected by ROC-AUC. These values describe only the generated synthetic data and do not establish performance on real customers.

## Run tests

From the repository root:

```bash
pytest backend/tests -q
```

## Documentation

- [Project abstract](docs/ABSTRACT.md)
- [Full project report (Markdown)](docs/PROJECT_REPORT.md)
- [Full project report (Word)](docs/ChurnIQ_Project_Report.docx)
- [Abstract (Word)](docs/ChurnIQ_Project_Abstract.docx)
- [Backend setup](backend/README.md)
- [Machine-learning guide](docs/BACKEND_ML_GUIDE.md)
- [Source-code guide](docs/SOURCE_CODE_GUIDE.md)
- [Test cases](docs/TEST_CASES.md)
- [Viva code explanation](docs/VIVA_CODE_EXPLANATION.md)

## Project team

| Roll number | Student |
|---|---|
| 2420030321 | Madhu |
| 2420030699 | Hema |
| 2420030303 | Name to be confirmed |

Replace the third student's placeholder with the correct name before final submission.

## Limitations and future work

- The web frontend prediction is still a demo rule and needs API integration.
- The Copilot uses predefined local responses, not a live AI model.
- The sample dataset is synthetic and cannot validate real-world churn performance.
- Future work can connect the UI to the API, add real authorized data, tune models, calibrate probabilities, add explainability, and improve monitoring.

## Academic integrity note

Clearly disclose synthetic data and simulated frontend features in the project report and presentation. Only claim experiments, metrics, integrations and testing that your team has actually run and verified.

import pandas as pd
from backend.churniq.preprocessing import split_features_target

def test_split_features_target():
    frame = pd.DataFrame({
        "tenure": [1, 20, 5, 40],
        "contract": ["Monthly", "Annual", "Monthly", "Annual"],
        "Churn": [1, 0, 1, 0]
    })
    X, y = split_features_target(frame)
    assert list(X.columns) == ["tenure", "contract"]
    assert y.tolist() == [1, 0, 1, 0]

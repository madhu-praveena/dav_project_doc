"""Train and compare churn classifiers; save the selected model and metadata."""
from pathlib import Path
import json
import argparse
import joblib
import pandas as pd

from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier

from .preprocessing import load_dataset, split_features_target

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_DATA = ROOT / "data" / "customer_churn.csv"
MODEL_DIR = ROOT / "models"

def build_preprocessor(X: pd.DataFrame) -> ColumnTransformer:
    numeric = X.select_dtypes(include=["number"]).columns.tolist()
    categorical = X.select_dtypes(exclude=["number"]).columns.tolist()

    numeric_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])
    categorical_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore"))
    ])
    return ColumnTransformer([
        ("numeric", numeric_pipe, numeric),
        ("categorical", categorical_pipe, categorical)
    ])

def metric_summary(model, X_test, y_test):
    predictions = model.predict(X_test)
    probabilities = model.predict_proba(X_test)[:, 1]
    return {
        "accuracy": round(float(accuracy_score(y_test, predictions)), 4),
        "precision": round(float(precision_score(y_test, predictions, zero_division=0)), 4),
        "recall": round(float(recall_score(y_test, predictions, zero_division=0)), 4),
        "f1_score": round(float(f1_score(y_test, predictions, zero_division=0)), 4),
        "roc_auc": round(float(roc_auc_score(y_test, probabilities)), 4)
    }

def train(data_path: str | Path = DEFAULT_DATA):
    frame = load_dataset(data_path)
    X, y = split_features_target(frame)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    candidates = {
        "Logistic Regression": LogisticRegression(max_iter=1500, class_weight="balanced"),
        "Random Forest": RandomForestClassifier(
            n_estimators=300, random_state=42, class_weight="balanced",
            min_samples_leaf=2
        )
    }

    results = {}
    trained = {}
    for name, estimator in candidates.items():
        pipeline = Pipeline([
            ("preprocessor", build_preprocessor(X_train)),
            ("classifier", estimator)
        ])
        pipeline.fit(X_train, y_train)
        results[name] = metric_summary(pipeline, X_test, y_test)
        trained[name] = pipeline

    # Select by ROC-AUC, then F1 as a tie-breaker.
    selected_name = max(
        results, key=lambda name: (results[name]["roc_auc"], results[name]["f1_score"])
    )
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(trained[selected_name], MODEL_DIR / "churn_model.joblib")

    metadata = {
        "selected_model": selected_name,
        "features": X.columns.tolist(),
        "metrics": results,
        "target": "Churn",
        "positive_class": 1,
        "threshold": 0.5,
        "training_rows": int(len(X_train)),
        "testing_rows": int(len(X_test)),
        "note": "Metrics are from the held-out split of the supplied dataset."
    }
    (MODEL_DIR / "model_metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )
    print(json.dumps(metadata, indent=2))
    return metadata

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train ChurnIQ churn classifiers.")
    parser.add_argument("--data", default=str(DEFAULT_DATA), help="Path to churn CSV.")
    args = parser.parse_args()
    train(args.data)

"""Dataset loading and preprocessing helpers for the ChurnIQ ML pipeline."""
from pathlib import Path
import pandas as pd

TARGET_COLUMN = "Churn"
ID_COLUMNS = ["customerID"]

def load_dataset(csv_path: str | Path) -> pd.DataFrame:
    """Load a Telco-style churn CSV and perform basic type cleanup."""
    path = Path(csv_path)
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found: {path}. Place your authorized churn CSV at this path."
        )

    frame = pd.read_csv(path)
    if TARGET_COLUMN not in frame.columns:
        raise ValueError(f"Dataset must contain a '{TARGET_COLUMN}' target column.")

    frame = frame.drop(columns=[c for c in ID_COLUMNS if c in frame.columns])
    if "TotalCharges" in frame.columns:
        frame["TotalCharges"] = pd.to_numeric(frame["TotalCharges"], errors="coerce")

    frame[TARGET_COLUMN] = (
        frame[TARGET_COLUMN].astype(str).str.strip().str.lower()
        .map({"yes": 1, "no": 0, "1": 1, "0": 0})
    )
    frame = frame.dropna(subset=[TARGET_COLUMN])
    frame[TARGET_COLUMN] = frame[TARGET_COLUMN].astype(int)

    if frame.empty:
        raise ValueError("No valid records remain after target cleanup.")
    return frame

def split_features_target(frame: pd.DataFrame):
    """Return feature matrix and binary target vector."""
    if TARGET_COLUMN not in frame:
        raise ValueError(f"Missing target column: {TARGET_COLUMN}")
    X = frame.drop(columns=[TARGET_COLUMN])
    y = frame[TARGET_COLUMN]
    if y.nunique() < 2:
        raise ValueError("Training data must contain both churn classes.")
    return X, y

"""FastAPI service for predictions from a previously trained ChurnIQ model."""
from pathlib import Path
import json
import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parents[2]
MODEL_PATH = ROOT / "models" / "churn_model.joblib"
METADATA_PATH = ROOT / "models" / "model_metadata.json"

app = FastAPI(
    title="ChurnIQ Prediction API",
    description="Predicts customer churn using a locally trained classification pipeline.",
    version="1.0.0"
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:5500", "http://localhost:5500"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class PredictionRequest(BaseModel):
    customer: dict = Field(..., description="Feature values matching the training dataset columns.")

def load_artifacts():
    if not MODEL_PATH.exists() or not METADATA_PATH.exists():
        raise RuntimeError(
            "Model artifacts are missing. Run `python -m churniq.train_model` first."
        )
    model = joblib.load(MODEL_PATH)
    metadata = json.loads(METADATA_PATH.read_text(encoding="utf-8"))
    return model, metadata

@app.get("/health")
def health():
    ready = MODEL_PATH.exists() and METADATA_PATH.exists()
    return {"status": "ready" if ready else "model_not_trained"}

@app.get("/model-info")
def model_info():
    try:
        _, metadata = load_artifacts()
        return metadata
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

@app.post("/predict")
def predict(request: PredictionRequest):
    try:
        model, metadata = load_artifacts()
        expected = metadata["features"]
        missing = [name for name in expected if name not in request.customer]
        if missing:
            raise HTTPException(
                status_code=422,
                detail={"message": "Missing required customer features.", "missing": missing}
            )

        row = {name: request.customer[name] for name in expected}
        sample = pd.DataFrame([row], columns=expected)
        probability = float(model.predict_proba(sample)[0][1])
        threshold = float(metadata.get("threshold", 0.5))
        predicted = int(probability >= threshold)
        risk = "High" if probability >= 0.70 else "Medium" if probability >= 0.40 else "Low"

        return {
            "churn_probability": round(probability, 4),
            "predicted_churn": predicted,
            "risk_category": risk,
            "model": metadata["selected_model"],
            "disclaimer": "Prediction is model-based, not a guarantee of customer behaviour."
        }
    except HTTPException:
        raise
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Could not process prediction: {exc}") from exc

# Machine Learning Backend Guide

The project now includes an optional Python backend extension.

## Pipeline
1. Load a customer churn CSV.
2. Remove the customer identifier if present and clean the target.
3. Impute missing numerical and categorical values.
4. Scale numeric features and one-hot encode categorical features.
5. Train Logistic Regression and Random Forest classifiers.
6. Evaluate using accuracy, precision, recall, F1-score and ROC-AUC.
7. Select the model using ROC-AUC, with F1-score as a tie-breaker.
8. Save the trained pipeline and expose predictions through FastAPI.

## Important
A synthetic 5,000-row dataset is included in `data/customer_churn.csv`. You can train immediately using the commands in `backend/README.md`. Clearly label all resulting metrics as experiments on synthetic data, not real-world performance. The existing frontend still uses a JavaScript demo score until separately connected to the API.

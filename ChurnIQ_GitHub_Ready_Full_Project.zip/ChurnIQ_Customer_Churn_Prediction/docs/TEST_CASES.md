# Test Cases – ChurnIQ

| Test ID | Test case | Steps | Expected result | Actual result |
|---|---|---|---|---|
| TC01 | Launch application | Open the HTML file in a browser | Dashboard loads | To be recorded |
| TC02 | Navigate pages | Select each navigation item | Correct section appears | To be recorded |
| TC03 | Demo prediction | Enter valid customer values and submit | Illustrative risk output appears | To be recorded |
| TC04 | Customer details | Select a customer | Detail view opens | To be recorded |
| TC05 | Copilot | Enter a supported question | Local response appears | To be recorded |
| TC06 | CSV export | Select export action | CSV download begins | To be recorded |
| TC07 | Responsive layout | Resize browser to mobile width | Layout adapts | To be recorded |

Execute these tests and replace the actual-result placeholders with observed outcomes.

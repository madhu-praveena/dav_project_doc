"""Generate a reproducible synthetic customer churn dataset for ChurnIQ."""
from pathlib import Path
import numpy as np
import pandas as pd

SEED = 20261106
N_ROWS = 5000
OUT = Path(__file__).resolve().parent / "customer_churn.csv"

def main():
    rng = np.random.default_rng(SEED)
    n = N_ROWS
    genders = rng.choice(["Female", "Male"], n)
    senior = rng.binomial(1, 0.16, n)
    partner = rng.choice(["Yes", "No"], n, p=[0.48, 0.52])
    dependents = np.where(partner == "Yes",
        rng.choice(["Yes", "No"], n, p=[0.48, 0.52]),
        rng.choice(["Yes", "No"], n, p=[0.12, 0.88]))
    tenure = rng.integers(0, 73, n)
    phone = rng.choice(["Yes", "No"], n, p=[0.9, 0.1])
    multiple = np.where(phone == "Yes",
        rng.choice(["Yes", "No", "No phone service"], n, p=[0.42, 0.53, 0.05]),
        "No phone service")
    internet = rng.choice(["DSL", "Fiber optic", "No"], n, p=[0.35, 0.48, 0.17])

    def service(p):
        return np.where(internet == "No", "No internet service",
            rng.choice(["Yes", "No"], n, p=[p, 1-p]))

    security, backup = service(.42), service(.52)
    protection, support = service(.50), service(.40)
    tv, movies = service(.56), service(.54)
    contract = rng.choice(["Month-to-month", "One year", "Two year"], n, p=[.56,.23,.21])
    paperless = rng.choice(["Yes","No"], n, p=[.68,.32])
    payment = rng.choice(["Electronic check","Mailed check","Bank transfer (automatic)","Credit card (automatic)"],
                         n, p=[.34,.12,.28,.26])
    monthly = (20 + (internet=="Fiber optic")*38 + (internet=="DSL")*22
        + (phone=="Yes")*18 + (multiple=="Yes")*8 + (security=="Yes")*5
        + (backup=="Yes")*4 + (protection=="Yes")*5 + (support=="Yes")*6
        + (tv=="Yes")*7 + (movies=="Yes")*7 + rng.normal(0,5,n))
    monthly = np.clip(monthly,18,125).round(2)
    total = (monthly*tenure + rng.normal(0,25,n)).clip(0).round(2)
    logit = (-1.55 + 1.05*(contract=="Month-to-month") - .85*(contract=="Two year")
        - .022*tenure + .014*(monthly-65) + .55*(payment=="Electronic check")
        + .45*(support=="No") + .35*(security=="No") + .30*(paperless=="Yes")
        + .25*senior + rng.normal(0,.45,n))
    probability = 1/(1+np.exp(-logit))
    churn = np.where(rng.random(n)<probability,"Yes","No")
    frame = pd.DataFrame({
        "customerID":[f"SYN{i:06d}" for i in range(1,n+1)],
        "gender":genders,"SeniorCitizen":senior,"Partner":partner,"Dependents":dependents,
        "tenure":tenure,"PhoneService":phone,"MultipleLines":multiple,
        "InternetService":internet,"OnlineSecurity":security,"OnlineBackup":backup,
        "DeviceProtection":protection,"TechSupport":support,"StreamingTV":tv,
        "StreamingMovies":movies,"Contract":contract,"PaperlessBilling":paperless,
        "PaymentMethod":payment,"MonthlyCharges":monthly,"TotalCharges":total,"Churn":churn
    })
    for col in ["tenure","MonthlyCharges","TotalCharges"]:
        frame.loc[rng.random(n)<.012,col]=np.nan
    frame.to_csv(OUT,index=False)
    print(f"Wrote {len(frame)} synthetic rows to {OUT}")

if __name__ == "__main__":
    main()

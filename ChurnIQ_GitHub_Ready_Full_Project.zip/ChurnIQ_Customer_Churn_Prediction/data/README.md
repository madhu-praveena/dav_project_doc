# ChurnIQ Synthetic Dataset

## Files
- `customer_churn.csv`: 5,000 synthetic customer records for model development and classroom demonstration.
- `customer_churn_sample_100.csv`: first 100 rows for quick inspection.
- `DATA_DICTIONARY.csv`: column descriptions and data types.
- `generate_synthetic_data.py`: reproducible generator (seed `20261106`).

## Important disclosure
This dataset is **artificially generated**. It does not contain real customers and is not an official telecom dataset. Churn labels are generated from a probabilistic rule using tenure, contract type, charges, payment method and service attributes. Consequently, models trained on this dataset learn patterns created by the generator, not verified real-world customer behaviour.

Use this dataset for development, testing, demonstration and coursework practice only. In your report and presentation, call it a **synthetic dataset** and do not claim that its results represent a real telecom company.

## Schema compatibility
The dataset includes a `Churn` target column with `Yes`/`No` labels and Telco-style features. It is compatible with the supplied ChurnIQ preprocessing and training scripts. The `customerID` identifier is dropped by the preprocessing code. A small number of numeric values are intentionally missing to demonstrate imputation.

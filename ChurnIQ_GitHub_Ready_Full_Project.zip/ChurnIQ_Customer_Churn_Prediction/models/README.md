# Model artifacts

The trained files are generated locally by the training script:
- `churn_model.joblib`
- `model_metadata.json`

They are intentionally not pre-generated because no verified training dataset was supplied with this project. Run the training command after adding an authorized dataset.
